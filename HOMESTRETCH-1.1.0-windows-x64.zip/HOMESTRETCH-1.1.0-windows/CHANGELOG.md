# Changelog

## 1.1.0 — graphics update (2026-11-08)

### Horses and riders
- New sculpted horse: every body part is a single smooth lofted mesh (chest, withers, barrel, croup, muscled
  shoulders and haunches, deep neck, tapered head with eyes and nostrils, forearms, gaskins, fetlocks, flared hooves).
- Coat shader: per-horse tonal variation, black points on bays, grey dapples, white socks/stockings and
  star/stripe/blaze painted onto the head shape, hair sheen and underside shading. Separate streaked mane/tail hair.
- Tack: shaped saddlecloth that drapes over the barrel, saddle, girth, noseband and browband, reins from the jockey's hands to the bit.
- New jockey: lofted body, folded legs on short stirrups, silks with seven stable patterns (hoops, sash, quarters,
  spots, chevrons, braces, plain), contrasting cap with peak, goggles, gloves. Arm angles follow the torso lean.
- Soft contact shadow under every horse; hoof kickback particles (dust on dirt, clods on turf, mud spray on soft ground).

### Venues
- Track and grass shaders: multi-scale detail, wear along the inside rail, dirt hoof scuffs, turf divots, wet sheen and puddles.
- Sky shader with drifting clouds, sun disc and halo; cloud cover follows the weather.
- Spectators are now people (body + head, varied clothes and skin tones) who jump and cheer as the finish approaches.
- Layered broadleaf trees and conifers with wind sway; rounded hedges; rolling two-layer ridgelines instead of blob hills.
- Grandstands: coloured seat rows, roof fascia with brass stripe, flags; flower beds at Crownfield.
- Glow and colour grading (High preset). Larger, softer directional shadow map.
- Stable yard uses the same sky, ground, gravel and tree treatment.

### Fixes
- Race commentary and centre-screen messages ("They're off!") were positioned off-screen; now centred.

## 1.0.0 — first release (2026-11-08)

### Racing
- Deterministic fixed-timestep simulation (50 ms) on track coordinates with real extra ground on turns.
- Separate stamina and finishing reserve; exhaustion slows a horse sharply; reserve never refills.
- Traffic with predictive gap keeping, refused unsafe lateral moves, sheltering, dirt kickback, going, surface and distance suitability.
- AI jockeys with running plans, pace judgment, positioning, box escape ("take back and switch").
- Interpolated nose-crossing times, millisecond timing, dead heats with split prizes, photo-finish view.
- Riding controls, jockey hand-over at any time, assisted riding, tactical pause with queued commands, instant resolution using the same simulation.
- Three venues, weather and going, broadcast HUD, field map, commentary, four cameras, replays (seek, speed, horse/camera select), photo capture.

### Career
- 48-week calendar, 192 races/season, 8 named stakes, Crownfield Cup, Triple Laurel.
- Handicapper-style ratings measured against the field; rating-band classes; eligibility explained before paying.
- Training plans, development ceilings and maturation curves, fitness/fatigue, setbacks with causes and recovery.
- Market (private sales with offers, monthly auctions with NPC bidders), scouting, sale, retirement.
- Breeding with game genetics, regression to the mean, cosmetic inheritance, inbreeding warnings, gestation, pedigree.
- Six persistent rival stables that race, breed, retire and recruit; bounded world population with pedigree-preserving pruning.
- Facilities, staff, finances, loans, insolvency warnings, events, bulletin, standings, records, archive, 30 achievements, trophies.
- Scenarios (6), Quick Race with prediction tokens, Sandbox, three difficulties, tutorial, guide.

### Technical
- Atomic, validated, versioned saves with backups and rotating autosaves; export/import; deterministic continuation after reload.
- Automated test suite, 10,000-race stress test, 20 × 30-year career simulations, screenshot tours, shipped `--smoke-test`.
- Reproducible asset generation (audio, icon, title, splash) and release script.
