HOMESTRETCH: A Racing Dynasty — v1.1.0 (portable)

1. Keep this folder anywhere (Desktop, USB stick, Program Files...).
2. Double-click Homestretch.exe  (Linux: ./Homestretch.x86_64)
   Windows may show "Windows protected your PC" because the game is not code-signed:
   click "More info" then "Run anyway".
3. Saves are stored in %APPDATA%\Homestretch (Linux: ~/.local/share/Homestretch),
   NOT in this folder — moving or replacing the game folder never loses them.

No installation, account or internet connection is needed.
Minimum: 64-bit Windows 10/11 with an OpenGL 3.3 capable graphics driver.

Self-check: run  Homestretch.exe -- --smoke-test  from a command prompt in this
folder. It writes smoke_report.txt (FPS, GPU, save/load timings, PASS/FAIL) to
%APPDATA%\Homestretch.

How to play: docs\PLAYER_MANUAL.md   Controls: docs\CONTROLS.md
Known issues: docs\KNOWN_ISSUES.md   What's in 1.0: docs\SCOPE.md
