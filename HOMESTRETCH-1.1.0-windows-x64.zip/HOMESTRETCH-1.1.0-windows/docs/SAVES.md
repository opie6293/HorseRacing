# Saves, backups and moving the game

## Where saves live
| Platform | Folder |
|---|---|
| Windows | `%APPDATA%\Homestretch\` (e.g. `C:\Users\<you>\AppData\Roaming\Homestretch\`) |
| Linux | `~/.local/share/Homestretch/` |

Inside: `saves/` (careers), `replays/`, `photos/`, `exports/`, `settings.cfg`, `tokens.cfg` (Quick Race tokens).
The game folder itself never stores saves, so you can move, rename or replace it freely.
The **Load Career** dialog shows the exact folder path.

## How saving works
- Each career has a main save `<name>.json` plus three rotating autosaves `<name>__auto0..2.json`.
- Autosaves happen weekly, before race day, after results are settled, after purchases, sales and breeding.
- Every write goes to a temporary file, is **re-read and validated**, the previous file is kept as `.bak`, and only then is the new file swapped in. A crash during saving can't destroy the last good save.
- If the newest file is damaged, loading falls back to its `.bak` automatically and tells you.
- Settings are stored separately from careers.

## Backups
Copy the whole `Homestretch` folder above. To restore, copy it back while the game is closed.

## Export / import a career
**Load Career → Export** writes a `.hscareer` file to `exports/` (path shown). To import, paste a file path into the
Import box. Imported files are treated as untrusted: types, ranges and references are validated and nothing in them is executed.

## Crashes during a race
Race results are only applied once (each race has a settlement record). If the game closes mid-race, reload the
pre-race autosave and run the race again — entry fees are never charged twice and prizes are never paid twice.
Suspending a race mid-run is not supported in 1.0 (see SCOPE.md).
