# Scope decisions — HOMESTRETCH 1.0 (slimmed release)

The original product specification describes a multi-year commercial production. At the owner's request
("slim down the expectations into something you can deliver by yourself within this chat … playable on any
Windows PC"), this release implements a reduced but complete game. Every item below is an **explicit, documented
scope decision** — nothing was silently relabelled as "future work".

## Delivered (playable in the shipped build)

| Area | What ships |
|---|---|
| Live 3D races | Procedural horses + riders (shared rig, coat/markings/socks/tack/silks/numbers), 4-beat gallop with suspension phase and speed-matched stride, tired gait, rider posture by effort, winner celebration. Broadcast, chase, overhead and head-on cameras. Broadcast HUD (order, gaps, distance, time, field map), commentary ticker, photo-finish view from recorded crossing data. |
| Riding | Effort Conserve/Settle/Press/Drive, lane in/out, sustained drive (toggle or hold), direct ↔ jockey switching at any time, assisted riding, tactical pause with queued commands, skip-to-result (same sim). Keyboard remapping; gamepad buttons + analog stick. |
| Simulation | Fixed-timestep, seeded, deterministic; spline progress + lateral offset with real extra ground on turns; separate stamina and finishing reserve; traffic, blocking, refused unsafe moves, sheltering, dirt kickback, going, surface, distance suitability, fitness, fatigue, composure, bounded day form; interpolated nose-crossing times, ms timing and dead heats; evidence-based race explanations; sectionals and position chart. |
| Venues | **3** tracks (Willow Creek Downs — dirt; Cedar Vale Park — turf; Crownfield — turf, championship) with distinct geometry, lighting, crowds, scenery; distances 1,000–3,200 m; clear/overcast/rain with Firm/Good/Soft/Heavy going. |
| Calendar | 48-week year, 4 races/week (192/season), 8 named stakes incl. the Crownfield Cup and the three-race Triple Laurel series; maiden / rating-band / age-restricted / stakes / championship rules; eligibility explained before paying; bookmarks; season calendar with filters. |
| Career | Name/colours/emblem, 3 starting pairs, difficulties, sandbox (funds, reveal, dev speed, pressure). Weekly loop with advance preview, "next event" fast-forward, training plans (7), development with ceilings, fitness/fatigue, setbacks with causes/recovery, 5 upgradeable facilities, 4 staff roles with candidates, finances with ledger, forecast, loan, alerts, insolvency after 6 warned weeks, Relaxed rescue grant. |
| Market | Private sales (one offer with accept/counter/refuse), monthly auctions with NPC bidders and max-bid, scouting (form, workout, vet), sale and retirement with confirmations. |
| Breeding | Game-genetics with regression to the mean and bounded variation, cosmetic inheritance (coat incl. dominant grey, blaze, socks), inbreeding detection + warning, 44-week gestation, recovery interval, barn capacity, foal reports, 4-generation pedigree, offspring/siblings. |
| World | 6 persistent rival stables (~150 NPC racers) that race weekly, age, retire to stud/broodmare, breed, and recruit disclosed prospects; track records, standings, head-to-head, champions roll, Horse of the Year, searchable archive, bulletin. |
| Other modes | Quick Race (any track/distance/weather/strength/archetype; ride or watch; fictional-token win bets), 6 scenarios with objectives/deadlines/summaries. |
| Meta | 30 achievements, trophy cabinet, replay library (20 recent + 20 favourites), photo capture (F12), stable manager tutorial (skippable/replayable), in-game guide, settings (display, audio buses, accessibility, controls). |
| Reliability | Versioned JSON saves, atomic write + verify + backup, 3 rotating autosaves, damaged-save recovery, export/import with validation, deterministic continuation after reload. |
| Audio | Procedurally synthesised originals: hoofbeats (turf/dirt), breathing, gate, bell, crowd (event-driven mix), cheers, rain, stable ambience, UI sounds, two music loops, victory fanfare. |

## Reduced from the original specification (explicit cuts)

| Spec item | Decision | Effect on the player |
|---|---|---|
| Six venues | **Three** venues ship (one dirt, two turf). Red Mesa (synthetic), Harborlight (right-handed) and Ironwood were cut. The track builder supports more; adding them is data + lighting. | Less venue variety; all core tactical contrasts (tight dirt oval vs broad turf vs long championship straight) remain. |
| 24 named stakes | **8** named stakes (incl. Cup and Triple Laurel legs). | Fewer marquee targets per season. |
| Six facilities | **Five** (Stables, Gallop, Paddocks, Vet room, Breeding barn). Staff lodge cut; all four staff roles are available without it. | None functionally. |
| 40 event templates | **12** weekly event templates with eligibility and cooldowns. | Bulletins repeat sooner. |
| 24 jockeys with contracts/retainers | 24 fictional jockeys with pace judgment/positioning/composure, fees and preferred styles affect decisions only; **no retainers/availability calendar**. | Simpler jockey management. |
| Rider/horse animation clips | Procedural animation (idle, walk/trot, canter, gallop, tired gallop, celebration) — no authored skeletal clips. | Stylised but readable motion. |
| Suspend-and-quit mid-race | **Not implemented.** Crash/quit mid-race recovers the committed pre-race autosave; entry fees are not charged twice and prizes are only paid once (settlement guard). | Re-run the race after a crash. |
| Ultrawide-specific layouts, per-resolution test matrix | Layouts use 1600×900 canvas scaling with "expand"; verified at 1280×720/1600×900/1920×1080 in screenshots. 2560×1440 and ultrawide **not visually verified**. | Should scale; unverified. |
| Localisation through string tables | **English only**, strings inline. | No translation support in 1.0. |
| Controller rebinding | Keyboard is remappable; **gamepad buttons fixed** (shown in prompts). | — |
| Speech/voice, multiplayer, UGC, jumping, harness | Out of scope per original spec. | — |
| Exe icon embedding | The ZIP ships icon.ico and the window/taskbar icon is set at runtime; embedding into the .exe resource needs `rcedit` on Windows (not available here). | Explorer shows the default Godot icon for the .exe file itself. |
| Code signing / store publication | Not performed (needs owner credentials). | Windows SmartScreen may warn on first launch. |
