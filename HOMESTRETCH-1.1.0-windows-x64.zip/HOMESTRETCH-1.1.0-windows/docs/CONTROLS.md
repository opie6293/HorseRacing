# Controls reference

All keyboard bindings can be changed in **Settings → Controls**. Gamepad buttons are fixed (XInput layout shown).
No action requires rapid tapping.

## Racing

| Action | Keyboard (default) | Gamepad |
|---|---|---|
| Increase effort (Conserve → Settle → Press) | W / ↑ | D-pad ↑ / left stick up |
| Reduce effort | S / ↓ | D-pad ↓ / left stick down |
| Sustained drive (toggle; *hold* option in Settings) | Space | A |
| Move inward (toward the rail) | A / ← | D-pad ← / left stick left |
| Move outward | D / → | D-pad → / left stick right |
| Direct ↔ jockey control | Tab | X |
| Change camera (Broadcast / Chase / Overhead / Head-on) | C | Y |
| Tactical pause / pause menu | Esc / P | Start |
| Previous / next horse (watching, replays) | Q / E | LB / RB |
| Playback speed (watching, replays) | R | Right stick click |
| Hide / show HUD | H | Left stick click |
| Save photo | F12 | Back |

## Menus
Mouse; or arrow keys / D-pad to move focus, **Enter / Space / A** to activate, **Esc / B** to close dialogs and profiles.
Tooltips appear on hover and explain consequences.

## Replays
Play/pause, ×0.5/×1/×2/×4, seek slider, horse selection (Q/E), cameras (C), HUD toggle (H), photo (F12).
