# HOMESTRETCH — Player Manual

## The idea
You start with a modest yard, two imperfect horses and ₡25,000. Find races your horses can win, develop them,
discover hidden talent, and eventually breed the horse that wins the **Crownfield Cup** (week 44 every season).
The deeper goal is to win it with a **homebred**. The optional **Triple Laurel** asks one three-year-old to win
the Laurel Guineas (1,600 m), Derby (2,400 m) and St. Leger (2,800 m) in a single season.

## Modes
- **Career** — the main game; continues indefinitely after big wins.
- **Scenarios** — six challenges with objectives and deadlines (save a failing yard, revive a champion, breed a winner…).
- **Quick Race** — pick a track, distance, weather, field and horse type; ride or watch. Never affects careers.
  Includes a small spectator prediction game with fictional tokens (win bets at fixed odds; tokens can't be bought or used elsewhere).
- **Sandbox** — a career with chosen funds, optional exact stats, development speed and financial pressure. Saves are labelled SANDBOX.

Difficulty (Relaxed / Standard / Expert) changes costs, setback frequency, scouting certainty and how sharply rivals choose races.
Racing physics and horse abilities are identical at every level.

## The week
The year has **48 weeks** (12 months × 4). Time moves only when you press **Advance Week** — closing the game
never ages horses or spends money. Each week:
1. Check alerts, fitness and fatigue (**Stable** / **Horses**).
2. Set training plans (Rest, Light, Balanced, Speed, Stamina, Starting & settling, Rehabilitation).
3. Enter races (**Races**). Eligibility, suitability, prize split, fee and travel are shown before you pay.
4. Shop, scout, breed, upgrade as needed.
5. **Advance Week** — a preview lists costs, warnings and your races. Run your races on race day (ride, watch or instant), then the week resolves.

**▸▸ Next event** skips quiet weeks (up to 8) and stops for anything needing a decision.

## Horses
Six abilities: **Speed, Stamina, Acceleration, Finishing reserve, Agility, Composure**, plus best distance,
surface and going preferences, a running style and up to two traits. There is no overall rating — scouting
and specialisation matter. You see **estimates**: green bands for current ability, brass bands for the genetic
ceiling. They narrow as you race, train and scout.

- **Ability vs fitness vs fatigue:** ability is skill; fitness is short-term condition; fatigue is tiredness.
  A gifted but unfit horse underperforms. Rest clears fatigue without losing skill.
- **Development** slows as a horse nears its current ceiling; the ceiling rises as it matures (late developers peak later) and falls gently for veterans.
- **Setbacks** (soreness, strains, infections) mostly follow heavy work while tired. The profile explains the cause and recovery time; injured horses can't race.
- **Ratings** come from race results and decide which classes a horse can enter.

## Race day
Race card (runners, owners, jockeys, gates, form, forecast win chances from public information) →
optional **paddock** (observations reflect each horse's real condition) → **tactics** (running plan, pace preference,
passing approach, jockey) → choose **Ride directly**, **Let the jockey ride**, or **Instant result**.
Conditions and the random seed are committed before you choose, so watching, skipping or changing cameras never changes the result.

### Riding
The horse follows the course. You choose **effort** and **lane**:

| Effort | Use |
|---|---|
| Conserve | Saves energy; you'll lose ground. |
| Settle | The efficient cruising pace. Most of a race. |
| Press | Faster, costs ~30% more energy. Hold a position, chase a gap. |
| Drive | Uses the separate **finishing reserve** for a burst. It runs out in seconds and never refills. |

- Going wide on turns covers extra ground — the inside is shorter.
- Tracking another horse saves a little energy (but dislike-kickback horses suffer behind others on dirt).
- Horses can't pass through each other. If a move is unsafe it's refused and the HUD says why.
- Switch between **direct** and **jockey** control at any time (Tab / X) — no bonus, no reset.
- **Tactical pause** (Esc / Start) lets you inspect the race and queue a command.
- **Assisted riding** (Settings) lets your jockey handle lanes while you manage effort.

### After the race
Results show times, margins (nose, head, neck, lengths), prizes, **three evidence-based explanations**
(pace, ground covered, traffic, stamina, trip, fitness…), a position chart and sectional splits.
Close finishes get a photo-finish view built from the actual crossing data. Watch the replay at any speed;
replays are kept in **News & Records → Replays** (20 recent + 20 favourites).

## Money
Weekly costs: upkeep per horse, training, staff, facility upkeep, loan payments. Prizes pay 55/20/12/8/5% of the purse
to the first five. Cash trouble triggers warnings; after **six consecutive overdrawn weeks** the bank closes the stable.
Ways out: sell a horse, release staff, choose cheaper nearby races, or take the bank loan (₡15,000; repay ₡420/week).
Relaxed mode offers a one-off rescue grant.

## Market & scouting
- **Private sales:** fixed asking price; one offer (85%) — accepted, countered or refused (some sellers are attached to their horses).
- **Auctions** (week 3 of each month): bid the next increment or set a maximum; 5% buyer's premium; stall and funds are checked.
- **Scouting:** *Form review* (distance pattern, misleading form), *Workout* (narrows ability estimates), *Vet exam* (soundness, current health).

## Breeding
Retire a filly/mare (age 3+) or a colt/stallion (not a gelding) to breeding from its profile.
In **Breeding**, choose a mare and a stallion (yours or at stud for a fee) and review the expected foal.
Game genetics: potential averages the parents, pulled 20% toward the breed average, plus random variation —
great pairings raise your odds but never guarantee a champion. Coat colour and markings inherit separately and never affect ability.
Close relatives trigger an **inbreeding warning** (−4 to all foal potential).
Gestation is **44 weeks**; mares rest 4 weeks after foaling; the barn limits simultaneous pregnancies; each foal needs a stall.
Foals race from age 2. The **pedigree** shows four generations with links to every recorded ancestor.

## Facilities & staff
Stables (4 → 8 → 12 → 16 horses), Training gallop (+development), Paddocks (+recovery), Veterinary room (fewer, shorter setbacks),
Breeding barn (more pregnancies). Each upgrade has a cost, build time and weekly upkeep.
Hire a trainer, vet, scout and groom from a small candidate pool that refreshes each season.

## Saving
Careers autosave every week, before races, after results and after purchases. See [SAVES.md](SAVES.md).
