# HOMESTRETCH: A Racing Dynasty

An offline, single-player flat-racing and stable-management game. Build a small yard into a dynasty:
scout overlooked horses, train them, choose the right races, ride them yourself in live 3D races,
then breed the next generation and chase the Crownfield Cup with a homebred.

*Working title — provisional until release-name checks are complete.*

- **Engine:** Godot **4.4.1-stable** (official build `49a5bc7b6`), GDScript, Compatibility (OpenGL 3.3) renderer
- **Platforms:** Windows 10/11 64-bit (primary), Linux x86_64 (secondary)
- **No account, internet connection, LLM or paid service needed.** All content is local.

## Play the release

1. Unzip `HOMESTRETCH-1.1.0-windows-x64.zip` anywhere (USB stick, Desktop, Program Files…).
2. Run `Homestretch.exe`. Windows SmartScreen may warn because the build is unsigned: *More info → Run anyway*.
3. Saves go to `%APPDATA%\Homestretch\saves` — moving or deleting the game folder never touches them.

See [`docs/PLAYER_MANUAL.md`](docs/PLAYER_MANUAL.md) for how to play and [`docs/CONTROLS.md`](docs/CONTROLS.md) for controls.

Self-check on any PC: `Homestretch.exe -- --smoke-test` renders a 12-runner race for 8 s, runs a career week,
saves/reloads and writes `%APPDATA%\Homestretch\smoke_report.txt` (FPS, GPU, timings, PASS/FAIL).

## Repository layout

| Path | Contents |
|---|---|
| `project.godot`, `export_presets.cfg` | Project and export configuration (Windows + Linux presets) |
| `scenes/main.tscn` | Single entry scene; screens are built in code |
| `scripts/race_sim.gd` | Deterministic fixed-timestep race simulation (headless-capable) |
| `scripts/horse_factory.gd` | Horse generation, game genetics, development curves, valuation |
| `scripts/career.gd` | Career world: calendar, entries, settlement, training, economy, rivals, breeding, market, achievements |
| `scripts/data.gd` | Authored data: tracks, classes, calendar, stakes, jockeys, rivals, names |
| `scripts/save_system.gd`, `scripts/replay_store.gd` | Atomic saves/backups/import-export; deterministic replays |
| `scripts/scenarios.gd` | Six authored scenarios |
| `scripts/race/` | 3D presentation: procedural horse + rider rig, track builder, race view/HUD/cameras |
| `scripts/ui/` | All screens (title, hub, profile, race day, auction, settings, guide…) |
| `assets/` | Generated audio (WAV), title & splash art |
| `tools/` | Asset generators, build/test/lint scripts, pinned-engine wrappers |
| `tests/` | Automated tests, stress tests, long-run careers, screenshot tours |
| `docs/` | Manual, scope, QA report, known issues, asset manifest, progress file |

## Build from source

Requirements: Linux or Windows shell with Python 3 (+ Pillow and NumPy) and the pinned Godot 4.4.1 editor + export templates.

```bash
tools/build_release.sh
```

That script (see comments inside) regenerates audio and art, imports the project, runs the test suite,
exports Windows and Linux builds and writes the ZIPs to `release/`. Individual steps:

```bash
python3 tools/gen_audio.py
python3 tools/gen_art.py
tools/test.sh
tools/gd.sh --export-release "Windows Desktop" export/windows/Homestretch.exe
```

`tools/gd.sh` expects the engine at `/opt/godot/Godot_v4.4.1-stable_linux.x86_64`; set up per
[`docs/VERSIONS.md`](docs/VERSIONS.md).

## Documentation

- [Player manual](docs/PLAYER_MANUAL.md) · [Controls](docs/CONTROLS.md) · [Saves & backups](docs/SAVES.md)
- [Scope decisions](docs/SCOPE.md) — what this 1.0 contains and what was explicitly cut
- [QA report](docs/QA_REPORT.md) · [Known issues](docs/KNOWN_ISSUES.md) · [Changelog](CHANGELOG.md)
- [Asset manifest](docs/ASSET_MANIFEST.md) · [Credits](CREDITS.txt) · [Third-party notices](THIRDPARTY_NOTICES.txt)
- [Pinned versions](docs/VERSIONS.md) · [Progress & continuation](docs/PROGRESS.md)
