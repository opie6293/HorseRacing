# Known issues and limitations — 1.0.0

## Not verified on real Windows hardware
The Windows build was exported from the pinned toolchain and run under **Wine 9.0 on Linux with Mesa llvmpipe
(software OpenGL)**. That proves the EXE starts, renders, runs races, saves to `%APPDATA%` and reloads — it is not
proof of behaviour on a real Windows 11 PC with a real GPU driver. Run `Homestretch.exe -- --smoke-test` on target
hardware (see QA_REPORT.md for the full procedure).

## Performance numbers are unmeasured on GPUs
All rendering in development happened on a CPU software rasteriser (~4 FPS for a 12-runner race), which says nothing
about a real GPU. The renderer is the Compatibility (OpenGL 3.3) path with modest geometry (procedural low-poly
horses, instanced crowds/trees, one shadowed directional light). A Low preset disables shadows and MSAA.
The 60 FPS @ 1080p target is **unverified**.

## Gameplay / content
- Three venues ship instead of six; 8 named stakes instead of 24; 12 event templates instead of 40 (see SCOPE.md).
- No mid-race suspend: quitting during a race returns you to the pre-race autosave (no double charges or payouts).
- Gamepad buttons cannot be remapped (keyboard can). Gamepad input was exercised with simulated events only — no physical controller was available.
- English only.
- The Windows `.exe` file shows the default Godot icon in Explorer (the window/taskbar icon is correct at runtime);
  embedding needs `rcedit` on Windows. The game is not code-signed, so SmartScreen may warn.
- Horses are stylised procedural models with procedural animation rather than sculpted meshes and authored clips.
- Background (NPC-only, unseen) races run the same model at a 100 ms step instead of 50 ms, for speed.
  Any race with your runner, or any race you watch, uses the 50 ms step.
- Very occasionally a runner can be boxed in for 10–15 s near the finish; jockeys try to switch out, and the
  results screen explains it. This is intended as a tactical risk, not a bug, but it can feel harsh.
- The stable yard scene shows up to 16 horses; it is a management view, not an explorable space.

## Accessibility
- Interface scaling (100/115/130%), high contrast, reduced motion, colour-independent runner identification
  (numbers + names everywhere), no rapid tapping, hold/toggle drive, separate audio buses.
- Layouts verified by screenshot at 1280×720 and 1600×900 (and 130% text at 1280×720).
  2560×1440 and ultrawide aspect ratios were **not** visually verified.
