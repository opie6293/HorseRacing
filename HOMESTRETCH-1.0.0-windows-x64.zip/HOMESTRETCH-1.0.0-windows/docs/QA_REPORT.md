# QA report — HOMESTRETCH 1.0.0

Test environment: Linux x86_64 cloud container, 4 vCPU (Intel Xeon @ 2.1 GHz), 15 GB RAM, **no GPU**
(Mesa llvmpipe software OpenGL 4.5 under Xvfb), no audio device, no physical gamepad.
Engine: Godot 4.4.1-stable (official, `49a5bc7b6`). Windows build checked under Wine 9.0.

Each item below is marked **PASSED** (actually run here, with evidence), **PARTIAL**, or **UNVERIFIED**.

## Automated tests — PASSED
`tools/test.sh` → `tests/run_tests.gd`: **24 test groups, 3,257,809 assertions, 0 failures** (most assertions are per-step race invariants).

| Group | What it proves |
|---|---|
| inheritance_bounds, regression_no_inflation | 500 foals of elite parents stay in bounds; 15 generations of best×best selection don't inflate past the ceiling |
| breeding_eligibility, inbreeding_detection | geldings/racing/pregnant/recovering horses can't breed; no duplicate stud fee; parent/sibling/cousin detection; inbreeding penalty in preview |
| aging_and_stages, gestation_and_foaling | 48 weeks = 1 year; development ≤ potential; veteran decline; 44-week gestation; pedigree links; recovery interval; foals can't race |
| race_eligibility | maiden, rating bands, injury, fatigue, Laurel age rule, Cup rule, one race per horse per week |
| stamina_limits | energy ∈ [0,1], reserve never refills and is consumed only while driving, finite speeds |
| safe_movement | 25 crowded 12-runner races: zero overlaps beyond tolerance, nobody leaves the track |
| finish_ordering, dead_heat | ascending times/places, all finish; dead heats share a place and split the combined prizes |
| determinism, render_rate_independence | identical seeds + command streams → identical results; 17/30/60/144 FPS frame streams give identical results; one runner's tactics can't reroll others' draw/form |
| replay_reproduction | stored replay re-simulates to an identical final frame, winner and time |
| transactions_and_settle_once, withdraw_refund | fees charged once; second settlement refused (no double prize); ledger reconciles to cash; integer money; refunds once |
| calendar_advancement | 192 races/season, all named stakes present, year rollover, fields fill |
| save_restore | save → load restores state and RNG; **continuing after reload produces the same future** as continuing in memory |
| corrupt_save_recovery, import_validation | damaged newest save falls back to `.bak`; invalid data is refused before replacing a healthy file; malformed imports rejected; valid export/import round-trips |
| auction_limits, market_no_profit_loop | reserve < estimate; purchases blocked without stall; instant resale is always below purchase price |
| scenarios_apply, explanations | all six scenarios start valid and advance; every runner gets 1–3 explanations |

## Stress test, 10,000 seeded races — PASSED
`tests/stress_races.gd`, 4 shards × 2,500 (logs: `docs/qa/stress_shard_*.log`), final simulation code.
All 3 tracks × 8 distances (1,000–3,200 m) × 4 goings × 3 weather types × 6–12 runners, random fitness/fatigue,
random jockeys/plans, and random player commands injected into half the races.

| Check | Result |
|---|---|
| Races | 10,000 |
| Non-finishers | **0** |
| Overlap steps beyond tolerance | **0** |
| Track escapes | **0** |
| Out-of-range energy/reserve | **0** |
| Non-finite values | **0** |
| Duplicate placings (non dead-heat) | **0** |
| Payout inconsistencies (> purse) | **0** |
| Dead heats (any place) | 48 |
| Photo finishes (1st–2nd < 0.06 s) | 209 |
| Longest race time | 271.4 s (3,200 m, heavy) |

## Long-run careers, 20 × up to 30 seasons — PASSED (world) / PARTIAL (economy)
Full table: [`docs/qa/LONGRUN_SUMMARY.md`](qa/LONGRUN_SUMMARY.md). Six strategies (racer, breeder, trader, elite, sprinter, stayer).
- World health **PASSED**: adult NPC racers 146–157 every season; total records plateau ≈500 (max 605); saves ≤ 892 KB;
  no dangling pedigree references; no breeding-interval violations; foal-crop potential 62.6 → 64.0 over 30 years (no inflation);
  4.2 different stakes-winning stables per season on average.
- Economy **PARTIAL**: the elite small-stable bot ended every run with ₡650k–₡882k and won the Cup in 2 of 3 seeds;
  11 of 20 naive bots went insolvent (they overbuy and build every upgrade). Insolvency only after six warned weeks, as designed.
  No bot achieved the homebred-Cup dynasty objective; that path is supported (tested breeding → foal → racing) but not demonstrated end-to-end by simulation.

## Riding-matters check — PASSED
`tests/probe_riding.gd`: identical race and horse ridden five ways. Racing 8 m wide always lost ground (worst result in 2 of 3
seeds); driving from 1,200 m out never won; settling then driving late won or placed in the strongest seed. No single plan dominates.

## UI and flows — PASSED (by scripted run + screenshot review)
- `tests/ui_tour.gd` (1600×900): title, new career, every hub tab, profile, pedigree, race card, paddock, tactics, ridden race,
  chase camera, tactical pause, skip-to-result, results, quick race, settings.
- `tests/ui_tour2.gd` (1280×720): scenario start, breeding tab, foal profile and pedigree after foaling, market, auction bidding,
  settings and races at **130% text**, Quick Race card with a token bet, watched rain/dirt race, overhead/chase cameras, results, replay.
- `tests/release_shots.gd` (1920×1080): title, stable, profile, race card, broadcast, chase, finish, results (release_kit/screenshots).
- `tests/season_ui.gd`: a full 48-week season driven through the hub's own advance-preview/advance code paths with sensible
  race selection (starting pair "Turf & Dirt"): **completed to Year 2 Week 1 with no script errors — 42 starts, 11 wins,
  11 trophies, 9 achievements, cash ₡25,000 → ₡57,895, autosaves rotating correctly.**
- Defects found and fixed by these runs: hub not filling the window; race-day background hiding the 3D race; top bar overflowing
  at 130% text; stable horses hidden inside the barn; Breeding tab format-string error; starting filly not race-ready on week 1.

## Gamepad — PARTIAL (simulated events only)
`tests/gamepad_sim.gd` injects joypad events: D-pad moves menu focus, **A activates**, the race receives effort/lane/jockey
commands from D-pad/A/X, Y changes camera, Start opens the tactical pause → **PASS**.
This run found and fixed a real defect (Godot's default `ui_accept`/`ui_cancel` have no joypad buttons).
**No physical controller was tested; hot-plug toasts and vibration are UNVERIFIED on hardware.**

## Windows build — PARTIAL
- Exported with the official 4.4.1 Windows template (x86_64, embedded PCK, single EXE).
- Under **Wine 9.0 + Mesa llvmpipe**: `Homestretch.exe -- --smoke-test` → **PASS** (renders a 12-runner race, career week,
  instant race, save → reload → identical continuation; user data in `C:/users/<user>/AppData/Roaming/Homestretch/`).
- **Native Windows 11 with a real GPU: UNVERIFIED.** Procedure below.

## Performance — UNVERIFIED on target hardware
| Measured here (software rendering — not representative) | Value |
|---|---|
| 12-runner race, Wine + llvmpipe, 1280×720 | ~4 FPS (CPU rasteriser) |
| Race simulation, headless | ~85–100 µs per 50 ms step with 11 runners (≈0.25 s per 2,000 m race) |
| Weekly advance (3 background races + world) | ~0.35–0.5 s |
| Save / load (≈200–900 KB) | ~40 ms / ~12 ms |
The 60 FPS @ 1080p target could not be measured without a GPU.

## Audio — PARTIAL
All cues are generated and wired (hoofbeats synced to footfalls by surface, breathing, gate, bell, crowd swell, cheer, rain,
stable ambience, UI, music, fanfare). No audio device was available, so the **mix was not listened to**. All cues have visual equivalents.

## Release artifacts (this build)
SHA-256 checksums are in `release/SHA256SUMS.txt`, published beside the ZIPs (not embedded here, since this file ships inside them).
Both ZIPs were extracted fresh and smoke-tested: Windows EXE under Wine 9.0 → PASS; Linux binary natively (Xvfb, llvmpipe) → PASS.

## Not done / out of scope
See [SCOPE.md](SCOPE.md) for explicit scope cuts (3 venues, 8 stakes, no mid-race suspend, English only, etc.).

## Native Windows verification procedure (for the owner)
1. Copy `HOMESTRETCH-1.0.0-windows-x64.zip` to a Windows 10/11 PC, extract, run `Homestretch.exe` (SmartScreen: *More info → Run anyway*).
2. From a Command Prompt in that folder: `Homestretch.exe -- --smoke-test`, then open `%APPDATA%\Homestretch\smoke_report.txt`.
   Expect `RESULT: PASS`; note the FPS line (target ≥ 60 at 1080p on a modest gaming GPU).
3. Play: New Career → enter a race → Advance ▸ → Go to race day → Ride. Quit to title, restart the EXE, **Continue** — the career should resume.
4. Move the game folder elsewhere and launch again — saves remain (they live in `%APPDATA%`).
5. Plug in an Xbox-style controller: menus with D-pad/A/B, race with D-pad/A/X/Y/Start; unplug/replug to see the toast.
6. Settings: fullscreen/borderless/windowed, 1920×1080 and 2560×1440, Low preset, 130% text, mute each audio slider.
