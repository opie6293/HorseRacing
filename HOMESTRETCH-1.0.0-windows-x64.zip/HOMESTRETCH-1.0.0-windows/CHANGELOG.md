# Changelog

## 1.0.0 — first release (2026-11-08)

### Racing
- Deterministic fixed-timestep simulation (50 ms) on track coordinates with real extra ground on turns.
- Separate stamina and finishing reserve; exhaustion slows a horse sharply; reserve never refills.
- Traffic with predictive gap keeping, refused unsafe lateral moves, sheltering, dirt kickback, going, surface and distance suitability.
- AI jockeys with running plans, pace judgment, positioning, box escape ("take back and switch").
- Interpolated nose-crossing times, millisecond timing, dead heats with split prizes, photo-finish view.
- Riding controls, jockey hand-over at any time, assisted riding, tactical pause with queued commands, instant resolution using the same simulation.
- Three venues, weather and going, broadcast HUD, field map, commentary, four cameras, replays (seek, speed, horse/camera select), photo capture.

### Career
- 48-week calendar, 192 races/season, 8 named stakes, Crownfield Cup, Triple Laurel.
- Handicapper-style ratings measured against the field; rating-band classes; eligibility explained before paying.
- Training plans, development ceilings and maturation curves, fitness/fatigue, setbacks with causes and recovery.
- Market (private sales with offers, monthly auctions with NPC bidders), scouting, sale, retirement.
- Breeding with game genetics, regression to the mean, cosmetic inheritance, inbreeding warnings, gestation, pedigree.
- Six persistent rival stables that race, breed, retire and recruit; bounded world population with pedigree-preserving pruning.
- Facilities, staff, finances, loans, insolvency warnings, events, bulletin, standings, records, archive, 30 achievements, trophies.
- Scenarios (6), Quick Race with prediction tokens, Sandbox, three difficulties, tutorial, guide.

### Technical
- Atomic, validated, versioned saves with backups and rotating autosaves; export/import; deterministic continuation after reload.
- Automated test suite, 10,000-race stress test, 20 × 30-year career simulations, screenshot tours, shipped `--smoke-test`.
- Reproducible asset generation (audio, icon, title, splash) and release script.
